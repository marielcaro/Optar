# alphachannelremover
Xojo project for creating png without alpha channel.
