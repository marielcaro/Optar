#import <Cocoa/Cocoa.h>

@interface AQAboutView : NSView
{
    NSImage *aboutImage;
}
@end
