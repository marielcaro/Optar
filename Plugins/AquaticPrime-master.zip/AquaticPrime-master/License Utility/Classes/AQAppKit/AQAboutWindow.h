#import <Cocoa/Cocoa.h>

@interface AQAboutWindow : NSWindow <NSWindowDelegate>
{
}
@end
