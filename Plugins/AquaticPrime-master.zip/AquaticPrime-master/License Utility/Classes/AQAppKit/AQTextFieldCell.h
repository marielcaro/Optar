/* AQTextFieldCell */

#import <Cocoa/Cocoa.h>

@interface AQTextFieldCell : NSTextFieldCell
{
}
@end
