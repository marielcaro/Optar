/* AboutController */

#import <Cocoa/Cocoa.h>

@interface AboutController : NSWindowController
{
	IBOutlet NSWindow *window;
}
@end
