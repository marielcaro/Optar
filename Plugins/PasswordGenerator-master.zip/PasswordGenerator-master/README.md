# PasswordGenerator

Generate unique passwords with your own rules. Created for 2018 Xojo #JustCode Challenge.